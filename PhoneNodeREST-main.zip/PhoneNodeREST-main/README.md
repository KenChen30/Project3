# PhoneBookNode
You must include the following modules on the server
From the directory: 
  npm install mysql
  mpn install socket.io
# PhoneNodeREST
